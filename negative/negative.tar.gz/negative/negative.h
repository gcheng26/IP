/* The exports from negative.c.
 */

GType negative_get_type( void ); 
int negative( VipsImage *in, VipsImage **out, ... );
